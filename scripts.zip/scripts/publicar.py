"""Publica um post da fila (imagem única ou carrossel) no Instagram (graph.instagram.com).

Uso: python3 -I scripts/publicar.py fila/2026-10-29_xtudo-classico
Lê o token do .env e as URLs públicas de urls.txt. Nunca imprime o token.
"""
import json, os, sys, time, urllib.parse, urllib.request, urllib.error

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# No Mac o token vem do .env; na nuvem (sem .env) vem da variável de ambiente LILICAS_IG_TOKEN.
ENV_PATH = os.path.join(ROOT, ".env")
env = dict(l.strip().split("=", 1) for l in open(ENV_PATH) if "=" in l) if os.path.exists(ENV_PATH) else {}
TOKEN = env.get("IG_ACCESS_TOKEN") or os.environ.get("LILICAS_IG_TOKEN", "")
USER = env.get("IG_USER_ID") or os.environ.get("LILICAS_IG_USER_ID", "17841477395607464")
VER = env.get("GRAPH_API_VERSION", "v23.0")
if not TOKEN:
    sys.exit("CRITICO token ausente: sem .env e sem a variável LILICAS_IG_TOKEN.")
# Token IGAA (login do Instagram) usa graph.instagram.com; token EAA (login do Facebook) usa graph.facebook.com.
HOST = "graph.facebook.com" if TOKEN.startswith("EAA") else "graph.instagram.com"
API = f"https://{HOST}/{VER}"

pasta = os.path.join(ROOT, sys.argv[1])
post = json.load(open(os.path.join(pasta, "post.json"), encoding="utf-8"))
hist_path = os.path.join(ROOT, "historico", "publicados.json")
historico = json.load(open(hist_path)) if os.path.exists(hist_path) else []


def call(method, path, **params):
    params["access_token"] = TOKEN
    data = urllib.parse.urlencode(params).encode()
    url = f"{API}/{path}"
    if method == "GET":
        req = urllib.request.Request(url + "?" + data.decode())
    else:
        req = urllib.request.Request(url, data=data, method="POST")
    # media_publish nunca é repetido por timeout: poderia publicar o post duas vezes.
    repete_timeout = not path.endswith("media_publish")
    for tentativa in range(3):
        try:
            return json.load(urllib.request.urlopen(req, timeout=180))
        except urllib.error.HTTPError as e:
            corpo = json.loads(e.read() or b"{}").get("error", {})
            corpo.pop("fbtrace_id", None)
            if corpo.get("code") == 190:
                sys.exit(f"CRITICO token expirado ou invalido: {corpo}")
            # 9004: o Instagram não conseguiu baixar a imagem naquele momento; costuma passar na nova tentativa.
            if (corpo.get("is_transient") or corpo.get("code") in (4, 17, 32, 613, 9004)) and tentativa < 2:
                time.sleep(20 * (tentativa + 1))
                continue
            sys.exit(f"ERRO API em {path}: {corpo}")
        except OSError as e:
            if not repete_timeout:
                sys.exit(f"ERRO de rede em {path}: {e}. Confira no perfil se o post saiu antes de rodar de novo.")
            if tentativa < 2:
                print(f"  sem resposta em {path.split('/')[-1]}, tentando de novo...", flush=True)
                time.sleep(10 * (tentativa + 1))
                continue
            sys.exit(f"ERRO de rede em {path}: {e}")
    sys.exit(f"ERRO API em {path}: esgotou tentativas")


def esperar(cid):
    for _ in range(30):
        st = call("GET", cid, fields="status_code").get("status_code")
        if st == "FINISHED":
            return
        if st in ("ERROR", "EXPIRED"):
            sys.exit(f"ERRO contêiner {cid}: {st}")
        time.sleep(5)
    sys.exit(f"ERRO contêiner {cid}: tempo esgotado")


if any(h["id"] == post["id"] for h in historico):
    sys.exit("Post já publicado, nada a fazer.")
if not post.get("aprovado") or post.get("precisa_revisao_humana"):
    sys.exit("Post não aprovado ou aguardando revisão humana.")

# Na nuvem o historico/ não volta para o GitHub: confere direto no Instagram se a legenda já foi publicada.
recentes = call("GET", f"{USER}/media", fields="caption,permalink", limit=15).get("data", [])
for m in recentes:
    if (m.get("caption") or "").strip() == post["legenda"].strip():
        sys.exit(f"Post já publicado no Instagram ({m.get('permalink')}), nada a fazer.")

urls = dict(l.split() for l in open(os.path.join(pasta, "urls.txt")) if l.strip())
imagens = []
for s in post["slides"]:
    url = urls[s["arquivo"].rsplit(".", 1)[0]]
    if not url.startswith("https://"):
        sys.exit(f"URL inválida para {s['arquivo']}: {url}")
    imagens.append((s["arquivo"], url))

if len(imagens) == 1:
    # Imagem única: o contêiner já leva a legenda, sem filhos.
    pai = call("POST", f"{USER}/media", image_url=imagens[0][1], caption=post["legenda"])["id"]
else:
    filhos = []
    for arquivo, url in imagens:
        cid = call("POST", f"{USER}/media", image_url=url, is_carousel_item="true")["id"]
        esperar(cid)
        filhos.append(cid)
        print("item ok", arquivo, flush=True)
    pai = call("POST", f"{USER}/media", media_type="CAROUSEL", children=",".join(filhos), caption=post["legenda"])["id"]
esperar(pai)
if os.environ.get("TESTE") == "1":
    sys.exit(f"TESTE OK: contêiner {pai} criado e pronto; publicação final não executada.")
media_id = call("POST", f"{USER}/media_publish", creation_id=pai)["id"]
link = call("GET", media_id, fields="permalink").get("permalink")

historico.append({"id": post["id"], "media_id": media_id, "permalink": link,
                  "data": post["data_publicacao"], "tema": post["tema"], "gancho": post["gancho"],
                  "pilar": post["pilar"], "formato": post["formato"]})
json.dump(historico, open(hist_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("PUBLICADO", link)
