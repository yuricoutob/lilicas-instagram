#!/bin/bash
# Sobe as imagens de um post e publica no Instagram em seguida.
# Uso: bash scripts/publicar_agora.sh fila/AAAA-MM-DD_slug
set -e
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
PASTA="$1"; case "$PASTA" in /*) ;; *) PASTA="$RAIZ/$PASTA" ;; esac
bash "$RAIZ/scripts/upload_portal.sh" "$PASTA"
python3 -I -u "$RAIZ/scripts/publicar.py" "$PASTA"
