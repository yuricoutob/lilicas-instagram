#!/bin/bash
# Sobe os JPEGs de um post para o portal Livads (api_midia.php) e grava as URLs em urls.txt.
# O portal apaga as imagens sozinho depois de 3 dias; o Instagram copia a imagem na criação do contêiner.
# Chave: variável LIVADS_PORTAL_CHAVE ou linha LIVADS_PORTAL_CHAVE= no .env. Nunca imprime a chave.
# Perfil: variável IG_PERFIL ou linha IG_PERFIL= no .env (padrão lilicassanduicheria).
# Uso: bash scripts/upload_portal.sh fila/2026-10-29_xtudo-classico
ROOT=$(cd "$(dirname "$0")/.." && pwd)
valor_env() { grep -m1 "^$1=" "$ROOT/.env" 2>/dev/null | cut -d= -f2-; }
CHAVE=${LIVADS_PORTAL_CHAVE:-$(valor_env LIVADS_PORTAL_CHAVE)}
PERFIL=${IG_PERFIL:-$(valor_env IG_PERFIL)}
PERFIL=${PERFIL:-lilicassanduicheria}
PORTAL=${LIVADS_PORTAL_URL:-https://painel.livads.com.br}
[ -n "$CHAVE" ] || { echo "ERRO: LIVADS_PORTAL_CHAVE não definida."; exit 1; }

cd "$1" || exit 1
: > urls.txt
# A proteção anti-robô da hospedagem às vezes responde com um script que só grava um cookie
# (ex.: humans_21909=1) e recarrega. Guardamos esse cookie e reenviamos com ele.
COOKIE=""
for f in [0-9][0-9].jpg; do
  u=""
  for tentativa in 1 2 3 4; do
    resp=$(curl -s -m 90 ${COOKIE:+-b "$COOKIE"} -A "livads-instagram/1.0" -H "X-Portal-Chave: $CHAVE" -F acao=enviar -F "perfil=$PERFIL" -F "arquivo=@$f;type=image/jpeg" "$PORTAL/api_midia.php")
    novo=$(printf '%s' "$resp" | sed -n 's/.*document\.cookie *= *"\([A-Za-z0-9_]*=[A-Za-z0-9_]*\)".*/\1/p' | head -1)
    if [ -n "$novo" ]; then COOKIE="$novo"; echo "  desafio anti-robô do portal; reenviando com o cookie pedido"; continue; fi
    u=$(printf '%s' "$resp" | python3 -I -c 'import json,sys; print(json.load(sys.stdin).get("url",""))' 2>/dev/null)
    case "$u" in https://*) break ;; esac
    echo "  tentativa $tentativa falhou para $f: $(printf '%s' "$resp" | head -c 200)"
    sleep 10
  done
  case "$u" in
    https://*) echo "${f%.jpg} $u" | tee -a urls.txt ;;
    *) echo "ERRO: o portal não aceitou $f."; rm -f urls.txt; exit 1 ;;
  esac
done
echo "Pronto: $(wc -l < urls.txt | tr -d ' ') links gravados em urls.txt"
