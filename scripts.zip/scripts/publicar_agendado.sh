#!/bin/bash
# Publicação agendada da Lilica's (launchd br.com.livads.lilicas-instagram).
# Roda de 30 em 30 minutos; só age em ter/qui/sex/sáb entre 11h30 e 18h (Brasília), se existir
# fila/AAAA-MM-DD_* de hoje com "aprovado": true e ainda fora de historico/publicados.json.
# Assim, se o Mac estiver dormindo às 11h30, o post sai assim que ele acordar (até 18h).
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
LOG="$RAIZ/logs/agendado.log"
export TZ=America/Sao_Paulo
export PATH="/Library/Frameworks/Python.framework/Versions/3.12/bin:/usr/local/bin:/usr/bin:/bin"
HOJE=$(date +%F); DIA=$(date +%u); HM=$(date +%H%M)
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

case "$DIA" in 2|4|5|6) ;; *) exit 0 ;; esac
[ "$HM" -ge 1130 ] && [ "$HM" -lt 1800 ] || exit 0

PASTA=$(ls -d "$RAIZ"/fila/"$HOJE"_* 2>/dev/null | head -1)
[ -n "$PASTA" ] || { log "sem post na fila para $HOJE"; exit 0; }
ID=$(basename "$PASTA")
grep -q "\"$ID\"" "$RAIZ/historico/publicados.json" 2>/dev/null && exit 0
[ -e "$PASTA/.bloqueado" ] && exit 0

APROVADO=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1])).get("aprovado") is True)' "$PASTA/post.json")
if [ "$APROVADO" != "True" ]; then
  # Registra uma vez por dia para não encher o log.
  grep -q "$HOJE $ID não aprovado" "$LOG.aviso" 2>/dev/null || { echo "$HOJE $ID não aprovado" >> "$LOG.aviso"; log "$ID não aprovado: não publicado"; }
  exit 0
fi

# Trava para duas execuções não publicarem ao mesmo tempo.
TRAVA="$RAIZ/logs/.publicando"
mkdir "$TRAVA" 2>/dev/null || { log "outra publicação em andamento"; exit 0; }
trap 'rmdir "$TRAVA"' EXIT

export LIVADS_PORTAL_CHAVE="$(tr -d '\n\r ' < "$HOME/automacao/portal_api_chave.txt")"
log "publicando $ID"
if bash "$RAIZ/scripts/publicar_agora.sh" "$PASTA" >> "$LOG" 2>&1; then
  log "ok $ID"
else
  if tail -5 "$LOG" | grep -q "media_publish"; then
    # Falha no passo final: o post pode ter saído. Não repete; alguém confere o perfil e apaga .bloqueado se precisar.
    touch "$PASTA/.bloqueado"; log "FALHOU $ID no media_publish: bloqueado até conferência manual"
  else
    log "FALHOU $ID (nova tentativa em 30 min até 18h)"
  fi
  osascript -e "display notification \"Falhou o post $ID. Veja logs/agendado.log\" with title \"Instagram Lilica's\"" 2>/dev/null
fi
