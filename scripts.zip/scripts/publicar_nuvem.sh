#!/bin/bash
# Publicação pela rotina na nuvem (sem Mac). Publica o post de HOJE da fila, se aprovado.
# Só ter/qui/sex/sáb (Brasília); nunca segunda. Token em LILICAS_IG_TOKEN, chave do portal em LIVADS_PORTAL_CHAVE.
# O publicar.py confere no Instagram se a legenda já saiu, então rodar duas vezes não duplica.
# Uso: bash scripts/publicar_nuvem.sh            (publica)
#      TESTE=1 bash scripts/publicar_nuvem.sh    (sobe e monta o contêiner, não publica)
#      DATA=2026-11-12 TESTE=1 bash scripts/publicar_nuvem.sh   (testa outro dia)
set -e
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
export TZ=America/Sao_Paulo
HOJE=${DATA:-$(date +%F)}
DIA=$(date -d "$HOJE" +%u 2>/dev/null || date -j -f %F "$HOJE" +%u)
case "$DIA" in 2|4|5|6) ;; *) echo "FORA DO CALENDARIO: $HOJE não é ter/qui/sex/sáb."; exit 0 ;; esac
[ -n "$LILICAS_IG_TOKEN" ] || [ -f "$RAIZ/.env" ] || { echo "CRITICO: LILICAS_IG_TOKEN não definida."; exit 1; }
[ -n "$LIVADS_PORTAL_CHAVE" ] || { echo "CRITICO: LIVADS_PORTAL_CHAVE não definida."; exit 1; }
PASTA=$(ls -d "$RAIZ"/fila/"$HOJE"_* 2>/dev/null | head -1)
[ -n "$PASTA" ] || { echo "SEM POST: nenhuma pasta fila/${HOJE}_* no repositório."; exit 0; }
APROVADO=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1])).get("aprovado") is True)' "$PASTA/post.json")
[ "$APROVADO" = "True" ] || { echo "NAO APROVADO: $(basename "$PASTA")"; exit 0; }
mkdir -p "$RAIZ/historico"
echo "Post: $(basename "$PASTA")"
IG_PERFIL=lilicassanduicheria bash "$RAIZ/scripts/upload_portal.sh" "$PASTA"
python3 -I -u "$RAIZ/scripts/publicar.py" "${PASTA#$RAIZ/}"
