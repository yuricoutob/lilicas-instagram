"""Marca posts da fila como aprovados (ou reprovados) depois do ok do cliente.

Uso:
  python3 -I scripts/aprovar.py 2026-11-09 2026-11-11     aprova esses dias
  python3 -I scripts/aprovar.py todos                     aprova todos os posts futuros da fila
  python3 -I scripts/aprovar.py --desfazer 2026-11-13     volta para não aprovado
  python3 -I scripts/aprovar.py --listar                  mostra a situação da fila
"""
import glob, json, os, sys, datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = sys.argv[1:]
desfazer = "--desfazer" in args
args = [a for a in args if a != "--desfazer"]
hoje = datetime.date.today().isoformat()
hist = os.path.join(ROOT, "historico", "publicados.json")
publicados = {h["id"] for h in json.load(open(hist))} if os.path.exists(hist) else set()

for f in sorted(glob.glob(os.path.join(ROOT, "fila", "*", "post.json"))):
    p = json.load(open(f, encoding="utf-8"))
    dia = p["data_publicacao"]
    alvo = ("todos" in args and dia >= hoje) or dia in args
    if alvo and "--listar" not in args and p["id"] not in publicados:
        p["aprovado"] = not desfazer
        json.dump(p, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    situacao = "publicado" if p["id"] in publicados else ("APROVADO" if p.get("aprovado") else "aguardando")
    print(f"{dia} {p.get('horario', '')}  {situacao:10}  {p['formato']:9}  {p['tema']}")
