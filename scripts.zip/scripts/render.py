"""Renderiza os slides de um post da Lilica's em JPEG 1080x1350 (estilo da arte aprovada em 29/10/2026).

Uso: python3 -I scripts/render.py fila/AAAA-MM-DD_slug
Lê post.json; cada slide tem "layout" (capa, produto, lista, versus, etapa, cta).
Fotos: "foto": "f07" aponta para brand/fotos/f07.jpg. "foco" muda o enquadramento (CSS object-position).
Marcação: *palavra* vira amarelo.
"""
import base64, html, json, os, re, shutil, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
pasta = sys.argv[1] if os.path.isabs(sys.argv[1]) else os.path.join(ROOT, sys.argv[1])
CHROME = next(c for c in ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                          shutil.which("chromium") or "", shutil.which("google-chrome") or ""] if c and os.path.exists(c))
post = json.load(open(os.path.join(pasta, "post.json"), encoding="utf-8"))
slides = post["slides"]
TOTAL = len(slides)
RODAPE = "LILICA'S SANDUICHERIA • GOIÂNIA • DELIVERY 18H30 ÀS 23H"


def b64(path):
    return "data:image/jpeg;base64," + base64.b64encode(open(path, "rb").read()).decode()


def foto(s, chave="foto"):
    return b64(os.path.join(ROOT, "brand", "fotos", s[chave] + ".jpg"))


AVATAR = b64(os.path.join(ROOT, "brand", "avatar.jpg"))


def t(x):
    x = html.escape(x or "")
    return re.sub(r"\*(.+?)\*", r'<span class="am">\1</span>', x).replace("\n", "<br>")


CSS = """
@import url('https://fonts.googleapis.com/css2?family=Anton&family=Oswald:wght@400;500;600&family=Yellowtail&family=Inter:wght@400;500;600&display=block');
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:1080px;height:1600px;overflow:hidden;background:#24150e}
.slide{position:absolute;top:125px;left:0;width:1080px;height:1350px;overflow:hidden;font-family:'Inter',sans-serif;color:#f6e7cc}
.bg{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 35%,#3a2418 0%,#24150e 70%)}
.ph{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.sh{position:absolute;inset:0;background:linear-gradient(180deg,rgba(36,21,14,.88) 0%,rgba(36,21,14,.15) 34%,rgba(36,21,14,0) 55%,rgba(36,21,14,.55) 78%,rgba(36,21,14,.95) 100%)}
.tit{font-family:'Anton',sans-serif;text-transform:uppercase;line-height:.95;color:#f6e7cc;text-shadow:0 4px 18px rgba(0,0,0,.45)}
.scr{font-family:'Yellowtail',cursive;color:#f2b33d;text-shadow:0 3px 12px rgba(0,0,0,.5);line-height:1}
.am{color:#f2b33d}
.faixa{display:inline-block;background:#a3262a;color:#f6e7cc;font-family:'Oswald',sans-serif;font-weight:600;text-transform:uppercase;
  padding:18px 34px;transform:rotate(-2deg);box-shadow:0 8px 24px rgba(0,0,0,.4);letter-spacing:.5px}
.rod{position:absolute;left:0;right:0;bottom:52px;text-align:center;font-family:'Oswald',sans-serif;font-weight:500;
  font-size:25px;letter-spacing:4px;color:#e9d6b0}
.rod b{color:#f2b33d;font-weight:500}
.pag{position:absolute;top:44px;right:52px;font-family:'Oswald',sans-serif;font-size:24px;letter-spacing:2px;color:#e9d6b0;
  background:rgba(36,21,14,.6);padding:6px 16px;border-radius:30px}
.desc{font-family:'Oswald',sans-serif;font-weight:400;color:#e9d6b0;line-height:1.35}
.preco{display:inline-block;background:#f2b33d;color:#24150e;font-family:'Oswald',sans-serif;font-weight:600;border-radius:14px;padding:10px 26px}
.preco small{font-weight:500;font-size:.62em;letter-spacing:1px;text-transform:uppercase;margin-right:10px}
"""


def rodape():
    return '<div class="rod">' + RODAPE.replace("•", "<b>•</b>") + "</div>"


def pagina(i):
    return f'<div class="pag">{i + 1}/{TOTAL}</div>' if TOTAL > 1 else ""


def preco(p, tam=44, fixo=False):
    # fixo=True quando o Saipos mostra o preço sem "A partir de" (ex.: bebidas, X-Burguinho).
    pre = "" if fixo else "<small>a partir de</small>"
    return f'<div class="preco" style="font-size:{tam}px">{pre}{html.escape(p)}</div>' if p else ""


def L_capa(s, i):
    tam = s.get("tam", 170)
    return f"""<img class="ph" src="{foto(s)}" style="object-position:{s.get('foco', 'center')}">
<div class="sh"></div>
<div style="position:absolute;top:70px;left:60px;right:60px;text-align:center">
  <div class="tit" style="font-size:{tam}px">{t(s['titulo'])}</div>
  {f'<div class="scr" style="font-size:{s.get("tam_script", 120)}px;margin-top:-34px">{t(s["script"])}</div>' if s.get('script') else ''}
</div>
{f'<div style="position:absolute;left:50px;right:50px;bottom:150px;text-align:center"><div class="faixa" style="font-size:{s.get("tam_faixa", 52)}px">{t(s["faixa"])}</div></div>' if s.get('faixa') else ''}
{f'<div style="position:absolute;left:0;right:0;bottom:{s.get("preco_bottom", 290)}px;text-align:center">{preco(s["preco"], 50)}</div>' if s.get('preco') else ''}
{pagina(i)}{rodape()}"""


def L_produto(s, i):
    return f"""<div class="bg"></div>
<div style="position:absolute;top:60px;left:60px;right:60px;height:700px;border-radius:28px;overflow:hidden;box-shadow:0 20px 50px rgba(0,0,0,.5)">
  <img class="ph" src="{foto(s)}" style="object-position:{s.get('foco', 'center')}"></div>
<div style="position:absolute;top:800px;left:70px;right:70px">
  {f'<div class="scr" style="font-size:70px;margin-bottom:6px">{t(s["script"])}</div>' if s.get('script') else ''}
  <div class="tit" style="font-size:{s.get('tam', 84)}px">{t(s['titulo'])}</div>
  <div class="desc" style="font-size:31px;margin:20px 0 26px">{t(s.get('texto', ''))}</div>
  {preco(s.get('preco'))}
</div>
{pagina(i)}{rodape()}"""


def L_lista(s, i):
    itens = "".join(
        f"""<div style="display:flex;align-items:center;justify-content:space-between;gap:30px;padding:26px 0;border-bottom:2px dashed rgba(233,214,176,.25)">
  <div><div class="tit" style="font-size:52px">{t(it['nome'])}</div>
  {f'<div class="desc" style="font-size:{27 if len(s['itens']) > 3 else 31}px;margin-top:8px">{t(it["detalhe"])}</div>' if it.get('detalhe') else ''}</div>
  <div style="flex:none">{preco(it.get('preco'), 38, it.get('fixo'))}</div></div>""" for it in s["itens"])
    return f"""<div class="bg"></div>
<div style="position:absolute;top:70px;bottom:150px;left:80px;right:80px;display:flex;flex-direction:column;justify-content:center">
  <div class="tit" style="font-size:{s.get('tam', 110)}px;text-align:center">{t(s['titulo'])}</div>
  {f'<div class="scr" style="font-size:90px;text-align:center;margin-top:-20px">{t(s["script"])}</div>' if s.get('script') else ''}
  <div style="margin-top:40px">{itens}</div>
  {f'<div class="desc" style="font-size:28px;margin-top:34px;text-align:center">{t(s["nota"])}</div>' if s.get('nota') else ''}
</div>
{pagina(i)}{rodape()}"""


def L_versus(s, i):
    lado = lambda k, foco, nome: f"""<div style="position:relative;flex:1;overflow:hidden">
  <img class="ph" src="{foto(s, k)}" style="object-position:{foco}">
  <div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(36,21,14,.1) 50%,rgba(36,21,14,.92) 100%)"></div>
  <div class="tit" style="position:absolute;bottom:170px;left:0;right:0;text-align:center;font-size:76px">{t(nome)}</div></div>"""
    return f"""<div style="position:absolute;inset:0;display:flex;gap:8px;background:#f2b33d">
{lado('foto', s.get('foco', 'center'), s['nome_a'])}{lado('foto_b', s.get('foco_b', 'center'), s['nome_b'])}</div>
<div style="position:absolute;top:0;left:0;right:0;height:330px;background:linear-gradient(180deg,rgba(36,21,14,.92),rgba(36,21,14,0))"></div>
<div style="position:absolute;top:60px;left:40px;right:40px;text-align:center">
  <div class="tit" style="font-size:{s.get('tam', 120)}px">{t(s['titulo'])}</div>
  {f'<div class="scr" style="font-size:92px;margin-top:-22px">{t(s["script"])}</div>' if s.get('script') else ''}</div>
<div style="position:absolute;left:0;right:0;bottom:0;height:130px;background:#24150e"></div>
<div style="position:absolute;top:620px;left:50%;transform:translateX(-50%);width:150px;height:150px;border-radius:50%;background:#a3262a;
  border:6px solid #f6e7cc;display:flex;align-items:center;justify-content:center;font-family:'Anton';font-size:64px;color:#f6e7cc">VS</div>
{pagina(i)}{rodape()}"""


def L_etapa(s, i):
    return f"""<img class="ph" src="{foto(s)}" style="object-position:{s.get('foco', 'center')}">
<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(36,21,14,0) 45%,rgba(36,21,14,.94) 82%)"></div>
<div style="position:absolute;left:70px;right:70px;bottom:140px">
  {f'<div class="scr" style="font-size:78px">{t(s["script"])}</div>' if s.get('script') else ''}
  <div class="tit" style="font-size:{s.get('tam', 88)}px">{t(s['titulo'])}</div>
  {f'<div class="desc" style="font-size:32px;margin-top:18px">{t(s["texto"])}</div>' if s.get('texto') else ''}
</div>
{pagina(i)}{rodape()}"""


def L_cta(s, i):
    return f"""<div class="bg"></div>
<div style="position:absolute;top:60px;bottom:150px;left:80px;right:80px;text-align:center;display:flex;flex-direction:column;justify-content:center;align-items:center">
  <img src="{AVATAR}" style="width:220px;height:220px;border-radius:50%;border:6px solid #f2b33d;box-shadow:0 10px 30px rgba(0,0,0,.5)">
  {f'<div class="scr" style="font-size:96px;margin-top:40px">{t(s["script"])}</div>' if s.get('script') else ''}
  <div class="tit" style="font-size:{s.get('tam', 120)}px;margin-top:10px">{t(s['titulo'])}</div>
  {f'<div class="desc" style="font-size:36px;margin-top:30px">{t(s["texto"])}</div>' if s.get('texto') else ''}
  <div style="margin-top:60px"><div class="faixa" style="font-size:50px">{t(s.get('botao', 'Peça pelo link da bio'))}</div></div>
</div>
{pagina(i)}{rodape()}"""


LAYOUTS = {k[2:]: v for k, v in globals().items() if k.startswith("L_")}
os.makedirs(os.path.join(pasta, "html"), exist_ok=True)
for i, s in enumerate(slides):
    stem = f"{i + 1:02d}"
    doc = f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><style>{CSS}</style></head><body><div class="slide">{LAYOUTS[s["layout"]](s, i)}</div></body></html>'
    hp = os.path.join(pasta, "html", stem + ".html")
    open(hp, "w", encoding="utf-8").write(doc)
    png = os.path.join(pasta, "html", stem + ".png")
    subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=1",
                    "--window-size=1080,1600", "--virtual-time-budget=10000", "--run-all-compositor-stages-before-draw", f"--user-data-dir={os.path.join(pasta, 'html', 'chr')}",
                    f"--screenshot={png}", "file://" + hp], check=True, capture_output=True, timeout=180)
    jpg = os.path.join(pasta, stem + ".jpg")
    # Janela mais alta que o slide: o Chrome headless às vezes não pinta a última faixa da janela. O slide fica centralizado na janela de 1600px e o sips recorta o centro (o --cropOffset do sips é ignorado).
    subprocess.run(["sips", "-c", "1350", "1080", "-s", "format", "jpeg", "-s", "formatOptions", "90",
                    png, "--out", jpg], check=True, capture_output=True)
    s["arquivo"] = stem + ".jpg"
    print("ok", stem, flush=True)

shutil.rmtree(os.path.join(pasta, "html"), ignore_errors=True)
json.dump(post, open(os.path.join(pasta, "post.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
