# Estratégia de conteúdo: @lilicassanduicheria (hamburgueria delivery)

## Quem é
Sanduicheria artesanal em Goiânia (Setor Novo Horizonte), só delivery, das 18h30 às 23h (bio do Instagram).
Posicionamento da bio: "O verdadeiro sabor do sanduíche tradicional goiano. Feitos de forma artesanal com muito sabor."
Linhas do cardápio: X tradicional goiano (bem servido, no papel), smash, hambúrguer gourmet no brioche, combos, fritas.
Não é a mais barata: quer ser lembrada como opção confiável, saborosa e próxima do bairro (briefing).

## Público
Moradores da região de entrega em Goiânia: jovens, casais e famílias que pedem à noite.
Valorizam comodidade do link, lanche bem montado e entrega confiável.
Segunda e terça são os dias mais fracos (briefing). A loja não abre às segundas (usuária, 06/11/2026): nunca publicar na segunda. Terça leva oferta e combo.

## Calendário
Terça, quinta, sexta e sábado às 11h30 (Brasília), 4 posts por semana. Segunda não: a loja não abre.
Mesclar imagem única e carrossel curto (3 slides; máximo 4). Nunca 2 carrosséis seguidos; em média 50/50.

| Dia | Missão | Exemplos |
|---|---|---|
| Terça | vender no dia fraco | "terça sem cozinhar", combos com batata e refri, menor preço de entrada |
| Quinta | desejo de produto | um lanche só, close na foto, ingredientes do cardápio, preço "a partir de" |
| Sexta | ocasião | combo pra dividir, sexta de jogo ou série, turma reunida |
| Sábado | família e comunidade | pedido da família, enquete, "qual é o seu time", acompanhamentos |

## Pilares (girar; não repetir o mesmo pilar 2 vezes seguidas)
1. **Desejo** (foto grande do lanche, poucas palavras, ingredientes literais do cardápio).
2. **Oferta e combo** (o que vem, para quantas pessoas, preço do Saipos, como pedir).
3. **Ocasião** (terça sem cozinhar, sexta pra dividir, jogo, série, família).
4. **Comunidade** (enquete, "marca quem", "comenta seu time"; objetivo comentários).
5. **Bastidores** (fotos da cozinha e da bancada; mostrar cuidado, sem prometer o que não dá para provar).

## Regras inegociáveis
- Nome de lanche, ingrediente e preço só do brand/cardapio.md, escritos exatamente como no Saipos. Nunca inventar promoção, desconto, cupom, frete grátis, tempo de entrega, avaliação ou depoimento.
- Preço sempre "a partir de R$ X,XX" quando o Saipos mostra assim. Preço conferido no Saipos na semana da publicação.
- Foto só da pasta "Fotos Lilicas" (brand/fotos). A foto não pode ser chamada de um lanche diferente do que ela mostra; quando houver dúvida, marcar pendência para o cliente confirmar.
- Mesma foto no máximo 1 vez a cada 3 semanas. Com 4 posts por semana e 14 fotos, usar artes só de texto (layout lista) quando não houver foto adequada.
- Sem travessão ou meia-risca. Português do Brasil revisado. Emojis com moderação (até 3 por legenda).
- Sem política, religião ou polêmica.

## Legenda
1. Primeira linha = gancho igual ao da arte.
2. 1 a 3 linhas de sabor/ingredientes (texto do cardápio) ou da ocasião.
3. Serviço: "Delivery das 18h30 às 23h. Peça pelo link da bio."
4. Um único CTA de engajamento, diferente do post anterior (marca alguém, comenta, salva, manda pra quem divide).
5. 5 a 7 hashtags: #lilicassanduicheria #goiania #deliverygoiania #hamburguergoiania #lanchegoiania + 1 ou 2 do produto.

## Visual (scripts/render.py)
Estilo aprovado em 29/10/2026: fundo marrom, título Anton creme, assinatura Yellowtail amarela, faixa vermelha inclinada, rodapé "LILICA'S SANDUICHERIA • GOIÂNIA • DELIVERY 18H30 ÀS 23H".
Layouts: capa (foto cheia), produto (foto + nome + ingredientes + preço), lista (cardápio com preços), versus (enquete com 2 fotos), etapa (bastidores), cta (logo + botão).
