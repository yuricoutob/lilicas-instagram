# Cardápio Lilica's (cópia literal do Saipos)

Fonte: https://lilicassanduicherias.saipos.com/home, lido em 06/11/2026 com Chrome headless.
Endereço exibido: Avenida Mauricio Gomes Ribeiro - Setor Novo horizonte, 407. Bio do Instagram: Apenas delivery (18h30 às 23h).
Regra: nomes, ingredientes e preços só podem ser usados exatamente como abaixo. Preço sempre com "a partir de" quando o Saipos mostrar assim.


## X-SALADA PROMOCIONAL
X-SALADA CLÁSSICO
  Pão selado, hambúrguer artesanal ou filé de frango, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 20,90
X-BACON CLÁSSICO
  Pão selado, hambúrguer artesanal ou filé de frango, 2 bacon Sadia, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 23,90
X-TUDO CLÁSSICO
  Pão selado, hambúrguer artesanal ou filé de frango, 2 bacon Sadia, ovo frito, 1 salsichas Sadia mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 25,90
X-TUDO CLÁSSICO + REFRI LATA
  Pão selado, hambúrguer artesanal ou filé de frango, 2 bacon Sadia, ovo frito, 1 salsichas Sadia mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 29,90
2 X-TUDO CLÁSSICO + COCA COLA 1LT
  Pão selado, hambúrguer artesanal ou filé de frango, 2 bacon Sadia, ovo frito, 1 salsichas Sadia mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 59,90
3 X-TUDO CLÁSSICO + COCA COLA 2LT
  Pão selado, hambúrguer artesanal ou filé de frango, 2 bacon Sadia, ovo frito, 1 salsichas Sadia mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 87,90
X-BACON CLÁSSICO  + BATATA FRITA + REFRI LATA
  Pão selado, hambúrguer artesanal ou filé de frango, 2 bacon Sadia, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 33,90
X-TUDO CLÁSSICO + BATATA FRITA + REFRI LATA
  Pão selado, hambúrguer artesanal ou filé de frango, 2 bacon Sadia, ovo frito, 1 salsichas Sadia mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 35,90

## MENU KIDS
X-BURGUINHO
  Pão brioche selado na manteiga, hambúrguer artesanal Smash, queijo cheddar.
- Preço: R$ 18,90

## COMBO CASAL FAVORITO
2 X-TUDO BRUTO + 1 BATATA PEQUENA + 1 REFRIGERANTE 600ML
SAO 2 X-TUDAO
  Pão selado, hambúrguer artesanal 120gr ou filé de frango 150gr, 3 bacon Sadia, ovo frito, 2 salsichas Sadia, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 76,90
2 X-TUDO CLÁSSICO + 1 BATATA PEQUENA + 1 REFRIGERANTE 600ML
SAO 2 X-TUDAO
  Pão selado, hambúrguer artesanal ou filé de frango, 2 bacon Sadia, ovo frito, salsichas Sadia, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 65,90
2 CHEESEBURGUER BACON + 1 BATATA PEQUENA + 1 REFRIGERANTE 600ML
  SÃO 2 CHEESEBURGUER BACON: Pão brioche selado na manteiga, hambúrguer artesanal 180gr, 3 fatias de bacon Sadia, queijo cheddar, molho especial da casa e cebola caramelizada.
- Preço: A partir de R$ 74,90

## COMBOS PROMOCIONAIS
X-BACON SIMPLES + REFRIGERANTE LATA + BATATA FRITA
  Pão selado, hambúrguer artesanal 120gr ou filé de frango 150gr, 3 bacon Sadia, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha. Acompanha 1 refrigerante lata.
- Preço: A partir de R$ 38,90
X-TUDO + REFRIGERANTE LATA + BATATA FRITA
  Pão selado, hambúrguer artesanal 120gr ou filé de frango 150gr, 3 bacon Sadia, ovo frito, 2 salsichaS Sadia, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha. Acompanha 1 refrigerante lata.
- Preço: A partir de R$ 44,50
SMASH BURGUER BACON 2 CARNES + REFRIGERANTE LATA + BATATA
  Pão brioche selado na manteiga, 2 hambúrgueres artesanais Smash, 3 fatias de bacon Sadia, 2 queijos cheddar, molho especialda casa, 3 picles e cebola roxa picadinha. Acompanha 1 refrigerante lata e batata frita extra fina crocante.
- Preço: A partir de R$ 38,90
CHEESEBURGUER CLÁSSICO + REFRIGERANTE LATA + BATATA
  Pão brioche selado na manteiga, hambúrguer artesanal 180gr, queijo cheddar, molho especial da casa, cebola roxa picadinha. Acompanha 1 refrigerante lata e batata frita extra fina crocante
- Preço: A partir de R$ 36,90
CHEESEBURGUER BACON + REFRIGERANTE LATA + BATATA
  Pão brioche selado na manteiga, hambúrguer artesanal 180gr, 3 fatias de bacon Sadia, queijo cheddar, molho especial da casa e cebola caramelizada. Acompanha 1 refrigerante lata e batata frita extra fina crocante
- Preço: A partir de R$ 39,90
CHEESEBURGUER DOBRO DE CARNE COM BACON + REFRIGERANTE LATA + BATATA
  Pão brioche selado na manteiga, 2 hambúrgueres artesanais 180gr, 3 fatias de bacon Sadia, 2 queijos cheddar, molho especial da casa e cebola caramelizada. Acompanha 1 refrigerante lata e batata frita extra fina crocante
- Preço: A partir de R$ 48,90

## X-TRADICIONAL
X-SALADA SIMPLES
  Pão selado, hambúrguer artesanal 120gr ou filé de frango 150gr, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 24,50
X-BACON SIMPLES
  Pão selado, hambúrguer artesanal 120gr ou filé de frango 150gr, 3 bacon Sadia, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 27,90
X-BACON ESPECIAL
  Pão selado, hambúrguer artesanal 120gr ou filé de frango 150gr, 3 bacon Sadia, ovo frito, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 29,50
X-TUDO BRUTO
  Pão selado, hambúrguer artesanal 120gr ou filé de frango 150gr, 3 bacon Sadia, ovo frito, 2 salsichas Sadia, mussarela, presunto Sadia, alface crocante, tomate, milho e batata palha.
- Preço: A partir de R$ 32,50

## SMASH BURGUER
SMASH BURGUER 2 CARNES
  Pão brioche selado na manteiga, 2 hambúrgueres artesanais Smash, 2 queijos cheddar, molho especial da casa, 3 picles e cebola roxa picadinha.
- Preço: A partir de R$ 24,90
SMASH BURGUER BACON 2 CARNES
  Pão brioche selado na manteiga, 2 hambúrgueres artesanais Smash, 3 fatias de bacon Sadia, 2 queijos cheddar, molho especial, 3 picles e cebola roxa picadinha.
- Preço: A partir de R$ 27,90

## HAMBÚRGUER GOURMET
CHEESEBURGUER CLÁSSICO
  Pão brioche selado na manteiga, hambúrguer artesanal 180gr, queijo cheddar, molho especial da casa e cebola roxa picadinha.
- Preço: A partir de R$ 26,90
CHEESEBURGUER BACON
  Pão brioche selado na manteiga, hambúrguer artesanal 180gr, 3 fatias de bacon Sadia, queijo cheddar, molho especial da casa e cebola caramelizada.
- Preço: A partir de R$ 29,90
CHEESEBURGUER DOBRO DE CARNE COM BACON
  Pão brioche selado na manteiga, 2 hambúrgueres artesanais 180gr, 3 fatias de bacon Sadia, 2 queijos cheddar, molho especial da casa e cebola caramelizada.
- Preço: A partir de R$ 38,90

## FRITAS
NUGGETS DE FILE DE FRANGO - 5UN
- Preço: A partir de R$ 12,00
  BATATA FRITA 300gr
- Preço: A partir de R$ 19,90
NUGGETS DE FILE DE FRANGO - 10UN
- Preço: A partir de R$ 19,90
BATATA FRITA PEQUENA
- Preço: A partir de R$ 12,00
  BATATA FRITA CHEDDAR E BACON 300gr
- Preço: A partir de R$ 25,90
  BATATA FRITA MUSSARELA E BACON 300gr
- Preço: A partir de R$ 25,90

## BEBIDAS
COCA-COLA LATA
- Preço: R$ 7,00
COCA-COLA ZERO LATA
- Preço: R$ 7,00
GUARANÁ LATA
- Preço: R$ 7,00
GUARANÁ ZERO LATA
- Preço: R$ 7,00
PEPSI BLACK LATA
- Preço: R$ 7,00
FANTA LARANJA LATA
- Preço: R$ 7,00
SPRITE LIMÃO LATA
- Preço: R$ 7,00
SUCO LAFUIT MARACUJA LATA
- Preço: R$ 7,00
SUCO LAFRUIT UVA LATA
- Preço: R$ 7,00
SUCO LAFRUIT CAJU LATA
- Preço: R$ 7,00
  GUARANÁ 600ml
- Preço: R$ 10,00
  COCA-COLA 600ml
- Preço: R$ 10,00
  COCA-COLA ZERO 600ml
- Preço: R$ 10,00
COCA-COLA LITRO
- Preço: R$ 12,00
COCA-COLA ZERO LITRO
- Preço: R$ 12,00
GUARANÁ LITRO
- Preço: R$ 12,00
COCA-COLA 2 LITRO
- Preço: R$ 15,00
COCA-COLA ZERO 2 LITRO
- Preço: R$ 15,00
